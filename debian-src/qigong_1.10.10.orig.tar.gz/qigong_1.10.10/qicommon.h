#ifndef QICOMMON_H
#define QICOMMON_H

#define QICONNPORT 1264	    // the default qigong port

#endif
